package com.om.DataMagic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataMagicApplicationTests {

	@Test
	void contextLoads() {
	}

}
